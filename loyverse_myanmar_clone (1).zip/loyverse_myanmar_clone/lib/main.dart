import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const PosApp());

String money(int value) => '${NumberFormat('#,###').format(value)} ကျပ်';

class Product {
  final int id;
  final String name;
  final String category;
  final int price;
  final int stock;
  final IconData icon;
  const Product(this.id, this.name, this.category, this.price, this.stock, this.icon);
}

class Sale {
  final String id;
  final DateTime date;
  final int subtotal;
  final int discount;
  final int tax;
  final int total;
  final String payment;
  Sale({required this.id, required this.date, required this.subtotal, required this.discount, required this.tax, required this.total, required this.payment});
  Map<String, dynamic> toJson() => {'id': id, 'date': date.toIso8601String(), 'subtotal': subtotal, 'discount': discount, 'tax': tax, 'total': total, 'payment': payment};
  factory Sale.fromJson(Map<String, dynamic> j) => Sale(id: j['id'], date: DateTime.parse(j['date']), subtotal: j['subtotal'], discount: j['discount'], tax: j['tax'], total: j['total'], payment: j['payment']);
}

class PosApp extends StatelessWidget {
  const PosApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'SMK POS',
    theme: ThemeData(colorSchemeSeed: Colors.teal, useMaterial3: true, inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder())),
    home: const PosHome(),
  );
}

class PosHome extends StatefulWidget {
  const PosHome({super.key});
  @override
  State<PosHome> createState() => _PosHomeState();
}

class _PosHomeState extends State<PosHome> {
  final products = const [
    Product(1, 'ကော်ဖီ', 'အဖျော်ယမကာ', 1500, 18, Icons.local_cafe),
    Product(2, 'လက်ဖက်ရည်', 'အဖျော်ယမကာ', 1200, 7, Icons.coffee),
    Product(3, 'မုန့်ဟင်းခါး', 'အစားအစာ', 2500, 24, Icons.ramen_dining),
    Product(4, 'ထမင်းကြော်', 'အစားအစာ', 3500, 12, Icons.restaurant),
    Product(5, 'ရေသန့်', 'အဖျော်ယမကာ', 500, 4, Icons.water_drop),
    Product(6, 'အချိုရည်', 'အဖျော်ယမကာ', 1200, 30, Icons.local_drink),
    Product(7, 'ကိတ်မုန့်', 'မုန့်', 2800, 9, Icons.cake),
    Product(8, 'ဆန်းဒဝစ်', 'မုန့်', 3000, 16, Icons.lunch_dining),
  ];
  final cart = <int, int>{};
  final searchController = TextEditingController();
  List<Sale> sales = [];
  int tab = 0;
  String category = 'အားလုံး';
  String query = '';
  double discountRate = 0;
  bool taxEnabled = false;

  @override
  void initState() { super.initState(); _loadSales(); }
  @override
  void dispose() { searchController.dispose(); super.dispose(); }
  Future<void> _loadSales() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getStringList('sales') ?? [];
    if (mounted) setState(() => sales = raw.map((e) => Sale.fromJson(jsonDecode(e))).toList());
  }
  Future<void> _saveSales() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('sales', sales.map((e) => jsonEncode(e.toJson())).toList());
  }
  Product _product(int id) => products.firstWhere((p) => p.id == id);
  int get itemCount => cart.values.fold(0, (a, b) => a + b);
  int get subtotal => cart.entries.fold(0, (sum, e) => sum + _product(e.key).price * e.value);
  int get discount => (subtotal * discountRate).round();
  int get tax => taxEnabled ? ((subtotal - discount) * .05).round() : 0;
  int get total => subtotal - discount + tax;
  List<String> get categories => ['အားလုံး', ...{for (final p in products) p.category}];

  void _add(Product p) {
    if ((cart[p.id] ?? 0) >= p.stock) { _snack('လက်ကျန်မလုံလောက်ပါ'); return; }
    setState(() => cart[p.id] = (cart[p.id] ?? 0) + 1);
  }
  void _remove(Product p) => setState(() { final n = (cart[p.id] ?? 0) - 1; if (n <= 0) { cart.remove(p.id); } else { cart[p.id] = n; } });
  void _snack(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('SMK POS'), actions: [
      if (tab == 0) IconButton(tooltip: 'ဘားကုဒ်စကင်', onPressed: () => _snack('Barcode scanner ကို နောက်အဆင့်တွင် ချိတ်ဆက်နိုင်ပါသည်'), icon: const Icon(Icons.qr_code_scanner)),
      IconButton(tooltip: 'ဆက်တင်', onPressed: _settings, icon: const Icon(Icons.settings_outlined)),
    ]),
    body: tab == 0 ? _salePage() : _historyPage(),
    bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: const [
      NavigationDestination(icon: Icon(Icons.point_of_sale), label: 'အရောင်း'),
      NavigationDestination(icon: Icon(Icons.receipt_long), label: 'မှတ်တမ်း'),
    ]),
  );

  Widget _salePage() => Column(children: [
    Padding(padding: const EdgeInsets.fromLTRB(12, 12, 12, 6), child: SearchBar(controller: searchController, hintText: 'ကုန်ပစ္စည်းရှာရန်', leading: const Icon(Icons.search), trailing: [if (query.isNotEmpty) IconButton(onPressed: () { searchController.clear(); setState(() => query = ''); }, icon: const Icon(Icons.clear))], onChanged: (v) => setState(() => query = v))),
    SizedBox(height: 48, child: ListView.separated(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), itemCount: categories.length, separatorBuilder: (_, __) => const SizedBox(width: 8), itemBuilder: (_, i) => ChoiceChip(label: Text(categories[i]), selected: category == categories[i], onSelected: (_) => setState(() => category = categories[i])))),
    Expanded(child: _productGrid()),
    if (cart.isNotEmpty) _cartPanel(),
  ]);

  Widget _productGrid() {
    final visible = products.where((p) => (category == 'အားလုံး' || p.category == category) && p.name.contains(query)).toList();
    if (visible.isEmpty) return const Center(child: Text('ကုန်ပစ္စည်း မတွေ့ပါ'));
    return GridView.builder(padding: const EdgeInsets.fromLTRB(12, 4, 12, 12), gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, childAspectRatio: 1.15, crossAxisSpacing: 10, mainAxisSpacing: 10), itemCount: visible.length, itemBuilder: (_, i) {
      final p = visible[i];
      return Card(child: InkWell(borderRadius: BorderRadius.circular(12), onTap: () => _add(p), child: Padding(padding: const EdgeInsets.all(10), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(p.icon, size: 38, color: Colors.teal), const SizedBox(height: 5), Text(p.name, style: const TextStyle(fontWeight: FontWeight.bold)), Text(money(p.price), style: TextStyle(color: Colors.grey.shade700)), const SizedBox(height: 5),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.inventory_2_outlined, size: 14, color: p.stock < 8 ? Colors.orange : Colors.grey), const SizedBox(width: 3), Text('လက်ကျန် ${p.stock}', style: TextStyle(fontSize: 11, color: p.stock < 8 ? Colors.orange : Colors.grey))]),
      ])));
    });
  }

  Widget _cartPanel() => Card(margin: const EdgeInsets.fromLTRB(12, 0, 12, 8), child: Padding(padding: const EdgeInsets.all(12), child: Column(children: [
    Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('အော်ဒါ $itemCount ခု', style: const TextStyle(fontWeight: FontWeight.bold)), Text(money(total), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.teal))]),
    if (discountRate > 0 || taxEnabled) Padding(padding: const EdgeInsets.only(top: 4), child: Text('လျှော့ ${money(discount)}  •  အခွန် ${money(tax)}', style: const TextStyle(fontSize: 12, color: Colors.grey))),
    const SizedBox(height: 6),
    SizedBox(height: 34, child: ListView(scrollDirection: Axis.horizontal, children: cart.entries.map((e) { final p = _product(e.key); return Padding(padding: const EdgeInsets.only(right: 6), child: InputChip(label: Text('${p.name} ×${e.value}'), onPressed: () => _remove(p), onDeleted: () => setState(() => cart.remove(p.id))); }).toList())),
    const SizedBox(height: 6),
    Row(children: [Expanded(child: OutlinedButton.icon(onPressed: _showAdjustments, icon: const Icon(Icons.tune, size: 18), label: const Text('လျှော့/အခွန်'))), const SizedBox(width: 8), Expanded(child: FilledButton.icon(onPressed: _checkout, icon: const Icon(Icons.payment, size: 18), label: const Text('ငွေရှင်းမည်')))]),
  ]));

  Future<void> _showAdjustments() async {
    var rate = discountRate * 100; var tax = taxEnabled;
    await showDialog(context: context, builder: (_) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(title: const Text('လျှော့ဈေးနှင့် အခွန်'), content: Column(mainAxisSize: MainAxisSize.min, children: [Text('လျှော့ဈေး ${rate.round()}%'), Slider(value: rate, min: 0, max: 50, divisions: 10, label: '${rate.round()}%', onChanged: (v) => setLocal(() => rate = v)), SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('အခွန် ၅% ထည့်မည်'), value: tax, onChanged: (v) => setLocal(() => tax = v))]), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('ပယ်ဖျက်မည်')), FilledButton(onPressed: () { setState(() { discountRate = rate / 100; taxEnabled = tax; }); Navigator.pop(context); }, child: const Text('သိမ်းမည်'))])));
  }

  Future<void> _checkout() async {
    String payment = 'ငွေသား';
    final cash = TextEditingController(text: total.toString());
    final ok = await showDialog<bool>(context: context, builder: (_) => StatefulBuilder(builder: (context, setLocal) => AlertDialog(title: const Text('ငွေရှင်းခြင်း'), content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text('ကျသင့်ငွေ  ${money(total)}', style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 12), DropdownButtonFormField<String>(value: payment, decoration: const InputDecoration(labelText: 'ငွေပေးချေမှု'), items: const [DropdownMenuItem(value: 'ငွေသား', child: Text('ငွေသား')), DropdownMenuItem(value: 'KBZPay', child: Text('KBZPay')), DropdownMenuItem(value: 'WavePay', child: Text('WavePay'))], onChanged: (v) => setLocal(() => payment = v!)), const SizedBox(height: 12), TextField(controller: cash, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'ပေးငွေ', suffixText: 'ကျပ်'))]), actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('မလုပ်တော့ပါ')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('အတည်ပြုမည်'))])));
    if (ok != true || !mounted) { cash.dispose(); return; }
    final sale = Sale(id: DateTime.now().millisecondsSinceEpoch.toString(), date: DateTime.now(), subtotal: subtotal, discount: discount, tax: tax, total: total, payment: payment);
    setState(() { sales.insert(0, sale); cart.clear(); discountRate = 0; taxEnabled = false; });
    await _saveSales();
    cash.dispose();
    _snack('အရောင်းမှတ်တမ်း သိမ်းပြီးပါပြီ');
  }

  Widget _historyPage() => sales.isEmpty ? const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.receipt_long, size: 64, color: Colors.grey), SizedBox(height: 12), Text('အရောင်းမှတ်တမ်း မရှိသေးပါ')])) : ListView.builder(padding: const EdgeInsets.all(12), itemCount: sales.length, itemBuilder: (_, i) { final s = sales[i]; return Card(child: ListTile(leading: CircleAvatar(child: Text('${i + 1}')), title: Text(money(s.total), style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('${DateFormat('dd/MM/yyyy HH:mm').format(s.date)}  •  ${s.payment}\nလျှော့ ${money(s.discount)}  •  အခွန် ${money(s.tax)}'), isThreeLine: true, trailing: const Icon(Icons.chevron_right))); });

  void _settings() => showModalBottomSheet(context: context, showDragHandle: true, builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [Text('ဆိုင်ဆက်တင်', style: Theme.of(context).textTheme.titleLarge), const SizedBox(height: 16), const ListTile(leading: Icon(Icons.store), title: Text('SMK POS ဆိုင်'), subtitle: Text('Myanmar POS starter app')), ListTile(leading: const Icon(Icons.delete_sweep), title: const Text('အရောင်းမှတ်တမ်းဖျက်မည်'), onTap: () async { final p = await SharedPreferences.getInstance(); await p.remove('sales'); if (mounted) { setState(() => sales.clear()); Navigator.pop(context); } }), const SizedBox(height: 8)]))));
}
